<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- ==== FONT AWESOME ==== -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- ==== BOOTSTRAP JS ==== -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>

    <!-- ==== BOOSTRAP CSS ==== -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">

    <!-- ===== CSS ===== -->
    <link rel="stylesheet" href="./assets/css/admin.css" />

    <!-- ===== BOX ICONS ===== -->
    <link
      href="https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css"
      rel="stylesheet"
    />

    <title>Formal-shoe</title>
  </head>
  <body>
    <!--===== HEADER =====-->
    <header class="l-header" id="header">
      <nav class="nav">
          <a class="navbar-title" href="manage-products.php">
              <h3 class="nav-h3">Formal-Shoes Dashboard</h3>
          </a>
        <div class="nav__toggle" id="nav-toggle">
        </div>
        
    </div>
  </nav>
</header>

<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 col-lg-2 sidebar">
            <ul>
                <li><a href="manage-products.php"><i class="bx bxs-package"></i>Manage Products</a></li>
                <li><a href="orders.php"><i class="bx bxs-cart"></i>Orders</a></li>
                <li class="active"><a href="accounts.php"><i class="bx bxs-user"></i>User Accounts</a></li>
            </ul>
        </div>
        <!-- Main Content Area -->
        <div class="col-md-9 col-lg-10 main-content">
            <!-- Main content goes here -->
        </div>
    </div>
</div>

 
    <main>

        <section class="featured section bd-grid">

       
    <!-- Manage products section -->
    <section class="manage-users">
      <a href="add_user.php">
      <button  class="add-btn">Add User</button>
      </a>
        <h2 class="section-title">Manage Users</h2>
        <!-- Table to display shoe details -->
        <table class="shoe-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Fullname</th>
                    <th>Email</th>
                    <th>Action</th>
                </tr>
            </thead>
           
            <tbody>

            <?php 
            $servername = "localhost";
            $username = "nk";
            $password = "";
            $dbname = "formal-shoe";
  
            // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);
  
            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }
            
          // Fetch shoe data from the database
          $sql = "SELECT * FROM login";
          $result = mysqli_query($conn, $sql);

          if (mysqli_num_rows($result) > 0) {
            // Output data of each row
            while ($row = mysqli_fetch_assoc($result)) {
        
           echo "<tr>
            <td>" . $row['id']. "</td>
            <td>" .$row['fullname'] . "</td>
            <td>" . $row['email'] . "</td>
            <td>
                <a href='edit-user.php?id=" . $row['id'] ."'>
                <button class='edit-btn'>Edit</button>
                </a>

                <a href='delete-user.php?id=" . $row['id'] ."'>
                <button class='delete-btn'>Delete</button>
                </a>
            </td>
        </tr>
          </tbody>";
            }
          } else {
             echo "no information found";
          }
          mysqli_close($conn);
          ?>
        
      </section>
    </main>


    <!--===== MAIN JS =====-->
    <script src="assets/js/main.js"></script>
  </body>
</html>
