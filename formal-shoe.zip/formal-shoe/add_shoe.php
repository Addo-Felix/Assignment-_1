
<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

date_default_timezone_set('Africa/Accra');

// Database connection parameters
$servername = "localhost";
$username = "nk";
$password = "";
$dbname = "formal-shoe";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$currentDateTime = date('Y-m-d H:i:s');

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Get form data
    $name = $_POST['name'];
    $brand = $_POST['brand'];
    $price = $_POST['price'];
    $stock = $_POST['stock'];
    $image = addslashes(file_get_contents($_FILES['image']['tmp_name']));

    // Insert data into database
    $sql = "INSERT INTO shoe_detail (name, brand, price, stock, image, date_posted) VALUES  ('$name', '$brand', '$price', '$image', '$currentDateTime')";
    if (mysqli_query($conn, $sql)) {
        echo "<script>alert('shoe Uploaded'); window.location = 'manage-products.php';</script>";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }

    // Close database connection
    mysqli_close($conn);
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- ==== FONT AWESOME ==== -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- ==== BOOTSTRAP JS ==== -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>

    <!-- ==== BOOSTRAP CSS ==== -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">

    <!-- ===== CSS ===== -->
    <link rel="stylesheet" href="./assets/css/admin.css" />

    <!-- ===== BOX ICONS ===== -->
    <link
      href="https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css"
      rel="stylesheet"
    />

    <title>shoe</title>
  </head>
  <body>
    <!--===== HEADER =====-->
    <header class="l-header" id="header">
      <nav class="nav">
          <a class="navbar-title" href="manage-products.php">
              <h3 class="nav-h3">shoe-Commerce Dashboard</h3>
          </a>
        <div class="nav__toggle" id="nav-toggle">
        </div>
        
    </div>
  </nav>
</header>

<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 col-lg-2 sidebar">
            <ul>
                <li class="active"><a href="manage-products.php"><i class="bx bxs-package"></i>Manage Products</a></li>
                <li><a href="orders.php"><i class="bx bxs-cart"></i>Orders</a></li>
                <li><a href="accounts.php"><i class="bx bxs-user"></i>User Accounts</a></li>
            </ul>
        </div>
        <!-- Main Content Area -->
        <div class="col-md-9 col-lg-10 main-content">
            <!-- Main content goes here -->
        </div>
    </div>
</div>

 
    <main class="l-main">

        <section class="featured section bd-grid">

        
        <form action="add_shop.php" method="post" enctype="multipart/form-data">
        <label for="name">shoe Name:</label>
        <input type="text" id="name" name="name" required><br><br>
        <label for="name">shoe Brand:</label>
        <select id="brand" name="brand" class="brand_input">
        <option value="Lee Cooper">Lee Cooper</option>
        <option value="Bata">Bata</option>
        <option value="Hush Puppies">Hush Puppies</option>
        <option value="Red Chief">Red Chief</option>
        </select>
        <label for="price">Price:</label>
        <input type="number" id="price" name="price" inputmode="numeric" min="1" required><br><br>
        <label for="stock">Stock:</label>
        <input type="number" id="stock" name="stock" inputmode="numeric" min="1" required><br><br>
        <label for="image">Image:</label>
        <input type="file" id="image" name="image" accept="image/*" required><br><br>
        <input type="submit" value="Add shoe">
    </form>
        
      </section>
    </main>


    <!--===== MAIN JS =====-->
    <script src="assets/js/main.js"></script>
  </body>
</html>
