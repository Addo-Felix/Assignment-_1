const showPassword = document.getElementById('showPassword');
const CshowPassword = document.getElementById('CshowPassword');
const hidePassword = document.getElementById('hidePassword');
const ChidePassword = document.getElementById('ChidePassword');
const passwordInput = document.getElementById('password');
const CpasswordInput = document.getElementById('Cpassword');


showPassword.addEventListener('click', () => {
    passwordInput.setAttribute('type', 'password');
    showPassword.style.display = 'none';
    hidePassword.style.display = 'block';
});

hidePassword.addEventListener('click', () => {
    passwordInput.setAttribute('type', 'text');
    showPassword.style.display = 'block';
    hidePassword.style.display = 'none';
});

CshowPassword.addEventListener('click', () => {
    CpasswordInput.setAttribute('type', 'password');
    CshowPassword.style.display = 'none';
    ChidePassword.style.display = 'block';
});

ChidePassword.addEventListener('click', () => {
    CpasswordInput.setAttribute('type', 'text');
    CshowPassword.style.display = 'block';
    ChidePassword.style.display = 'none';
});



document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('mainS-submit-btn').addEventListener('click', function (event) {
        event.preventDefault();

        // Reset error messages for each input
        document.getElementById('fullname-error').innerHTML = ''; // Reset fullname error message
        document.getElementById('email-error').innerHTML = ''; // Reset email error message
        document.getElementById('password-error').innerHTML = ''; // Reset password error message
        document.getElementById('confirm-password-error').innerHTML = ''; // Reset confirm password error message

        // Retrieve form data
        var fullname = document.querySelector('input[name="fullname"]').value;
        var email = document.querySelector('input[name="email"]').value;
        var password = document.querySelector('input[name="password"]').value;
        var confirmPassword = document.querySelector('input[name="Cpassword"]').value;

        // Validate full name
        if (fullname.trim() === '') {
            document.getElementById('fullname-error').innerHTML = 'Full name is required';
        }

        // Validate email
        if (email.trim() === '') {
            document.getElementById('email-error').innerHTML = 'Email is required';
        } else if (!isValidEmail(email)) {
            document.getElementById('email-error').innerHTML = 'Invalid email format';
        }

        // Validate password
        if (password.trim() === '') {
            document.getElementById('password-error').innerHTML = 'Password is required';
        } else if (password.length < 8) {
            document.getElementById('password-error').innerHTML = 'Password must be at least 8 characters long';
        }

        // Validate confirm password
        if (confirmPassword.trim() === '') {
            document.getElementById('confirm-password-error').innerHTML = 'Confirm password is required';
        } else if (confirmPassword !== password) {
            document.getElementById('confirm-password-error').innerHTML = 'Passwords do not match';
        }

        // Check if any error messages are displayed
        var fullnameError = document.getElementById('fullname-error').innerHTML;
        var emailError = document.getElementById('email-error').innerHTML;
        var passwordError = document.getElementById('password-error').innerHTML;
        var confirmPasswordError = document.getElementById('confirm-password-error').innerHTML;

        // If no errors, submit the form
        if (fullnameError === '' && emailError === '' && passwordError === '' && confirmPasswordError === '') {
            document.querySelector('form').submit();
        }

    });
});
        function isValidEmail(email) {
            var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return emailRegex.test(email);
        }


        function toggleDropdown() {
            var dropdown = document.getElementById("logout-dropdown");
            if (dropdown.style.display === "block") {
              dropdown.style.display = "none";
            } else {
              dropdown.style.display = "block";
            }
          }
          
          // Close the dropdown if the user clicks outside of it
          window.onclick = function(event) {
            if (!event.target.matches('.profile-icon')) {
              var dropdowns = document.getElementsByClassName("dw-content");
              for (var i = 0; i < dropdowns.length; i++) {
                var openDropdown = dropdowns[i];
                if (openDropdown.style.display === "block") {
                  openDropdown.style.display = "none";
                }
              }
            }
          }
          
          function logout() {
            window.location.href = "logout.php"; // Redirect to the logout PHP script
        }        

        function updateQuantity(input) {
            input.form.submit();

            var quantity = parseInt(input.value);
            var price = parseFloat(input.parentElement.querySelector('.cart-item__price-txt').innerText.replace('GH₵', ''));
            // Calculate the new subtotal
            var subtotal = quantity * price;
            
            
        
            // Update the subtotal displayed on the page
            input.parentElement.querySelector('.subtotal-price').innerText = 'GH₵' + subtotal.toFixed(2);
            
            
            updateTotalSubtotal();
            updateTotal();

            var id = input.getAttribute('data-id'); // Get the ID of the item
            var xhr = new XMLHttpRequest();
            xhr.open('POST', 'update_cart.php', true);
            xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    // Update the displayed subtotal and total on the page
                    input.parentElement.querySelector('.subtotal-price').innerText = xhr.responseText;
                    updateTotalSubtotal();
                    updateTotal();
                }
            };
        //  Send request to update quantity on the server 
        xhr.send('id=' + id + '&quantity=' + quantity);
    }
    
        function updateTotalSubtotal() {
            // Get all subtotal prices of items in the cart
            var subtotalElements = document.querySelectorAll('.subtotal-price');
            // Initialize total subtotal to 0
            var totalSubtotal = 0;
            // Loop through each subtotal element and add its value to the total subtotal
            subtotalElements.forEach(function(subtotalElement) {
                totalSubtotal += parseFloat(subtotalElement.innerText.replace('GH₵', ''));
            });
            // Update the total subtotal displayed on the page
            document.querySelector('.sub-price').innerText = 'GH₵' + totalSubtotal.toFixed(2);
        }

        function updateTotal() {
            var totalSubtotal = parseFloat(document.querySelector('.sub-price').innerText.replace('GH₵', ''));
            document.querySelector('.total-price').innerText = 'GH₵' + totalSubtotal.toFixed(2);
            }
            

            const searchForm = document.querySelector('.search-form');

            // Add event listener for key press
            searchForm.addEventListener('keypress', function(event) {
                // Check if the Enter key is pressed (key code 13)
                if (event.key === 'Enter') {
                    // Prevent the default form submission behavior
                    event.preventDefault();
            
                    // Submit the form
                    searchForm.submit();
                }
            });
            
            