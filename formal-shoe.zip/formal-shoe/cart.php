
<?php
session_start();

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    // Redirect to the login page
    header("Location: login.html");
    exit();
}

// Check if cart session variable is not set, initialize it as an empty array
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Generate a unique cart ID if it's not already set
if (!isset($_SESSION['cart_id'])) {
    $_SESSION['cart_id'] = uniqid('cart_');
}

                // Check if there is an action and it's adding an item to the cart
        if (isset($_GET['action']) && $_GET['action'] === 'add' && isset($_GET['id'])) {
            // Retrieve the ID from the URL parameter
            $shoe_id = $_GET['id'];

            // Connect to the database
            $servername = "localhost";
            $username = "nk";
            $password = "";
            $dbname = "formal-shoe";

            $conn = new mysqli($servername, $username, $password, $dbname);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Fetch details of the selected shoe
            $sql = "SELECT * FROM shoe_detail WHERE id = $shoe_id";
            $result = mysqli_query($conn, $sql);

            // Check if the query returned any results
            if (mysqli_num_rows($result) > 0) {
                // Loop through each item in the result set
                while ($row = mysqli_fetch_assoc($result)) {
                    // Extract shoe details
                    $shoe_name = $row['name'];
                    $shoe_price = $row['price'];
                    $shoe_img = $row['image'];
                    $sneaker_stock = $row['stock'];


                    // Determine quantity (default to 1 if not provided)
                    $quantity = isset($_POST['number']) ? $_POST['number'] : 1;
                    $subtotal = $shoe_price * $quantity;

                    if ($quantity > $sneaker_stock) {
                        echo "<script>alert('Not enough stock available'); window.location = 'shop.php';</script>";
                        exit();
                    }


                    // Check if the item already exists in the cart
                    $existing_item_key = array_search($shoe_id, array_column($_SESSION['cart'], 'id'));

                    if ($existing_item_key !== false) {
                        $_SESSION['cart'][$existing_item_key]['quantity'] = $quantity;
                        $_SESSION['cart'][$existing_item_key]['subtotal'] = $subtotal;
                    } else {
                        // Add the new item to the cart
                        $cart_item = array(
                            'id' => $shoe_id,
                            'name' => $shoe_name,
                            'price' => $shoe_price,
                            'quantity' => $quantity,
                            'subtotal' => $subtotal,
                            'image' => $shoe_img,
                            'stock' => $sneaker_stock
                        );

                        $_SESSION['cart'][] = $cart_item;

                    }
                }
            }
            
            // Close the database connection
            mysqli_close($conn);

            // Redirect back to products.php
            echo "<script>alert('Item added'); window.location = 'shop.php';</script>";
            exit();
        }
// Check if there is an action to remove an item from the cart
if (isset($_GET['action']) && $_GET['action'] === 'remove' && isset($_GET['id'])) {
    // Retrieve the ID of the item to remove from the cart
    $remove_id = $_GET['id'];

    // Loop through cart items to find the item to remove
    foreach ($_SESSION['cart'] as $key => $cart_item) {
        if ($cart_item['id'] === $remove_id) {
            // Remove the item from the cart
            unset($_SESSION['cart'][$key]);
            break; // Stop the loop once the item is removed
        }
    }

    // Redirect back to the cart page
    header("Location: cart.php");
    exit();
}


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- ==== FONT AWESOME ==== -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- ==== BOOTSTRAP JS ==== -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>

    <!-- ==== BOOSTRAP CSS ==== -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">

    <!-- ===== CSS ===== -->
    <link rel="stylesheet" href="./assets/css/styles.css" />

    <!-- ===== BOX ICONS ===== -->
    <link
    href="https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css"
    rel="stylesheet"
    />

    <title>Formal-shoe</title>
</head>
<body>
    <!--===== HEADER =====-->   
    <header class="l-header" id="header">
    <nav class="nav bd-grid">
        <div class="nav__toggle" id="nav-toggle">
        <i class="bx bxs-grid"></i>
        </div>

        <a href="index.html" class="nav__logo">Formal-Shoes</a>

        <div class="nav__menu" id="nav-menu">
        <ul class="nav__list">
            <li class="nav__item">
            <a href="index.php" class="nav__link">Home</a>
            </li>
        
            <li class="nav__item">
            <a href="shop.php" class="nav__link">Shop</a>
            </li>

            <li class="nav__item">
            <a href="cart.php" class="nav__link active">Cart</a>
            </li>
            <?php


// Check if the user is logged in
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {

      echo "<li class='nav__item'>";
      echo "<div class='profile'>";
      echo   " <i class='bx bx-user user-icon' id='account-icon' onclick='toggleDropdown()'></i>";
      echo "</div>";
      echo "</li>";
        echo '<div class="dropdown-content" id="logout-dropdown"><h5 class="logout-text" onclick="logout()">Logout</h5></div>';
  }  
   
    if(isset($_SESSION['logout']) && $_SESSION['logout'] === true) {
      // Unset all session variables
      // $_SESSION = array();
    
      // Destroy the session
      // session_destroy();
    
      // Redirect back to the index page
      header("Location: login.html");
      exit();
    }
    
    ?>


        </ul>
        </div>

        
    </nav>
    </header>

    <main class="main-cart">
    <section class="cart-section bd-grid">
            <div class="cart-left">
                <h2 class="cart-title">Shopping Cart</h2>
                <div class="cart-line"></div>
                <div class="cart-line2"></div>

                            <div class="cart-item__details">
                                <p class="cart-item__name">Product</p>
                                <p class="cart-item__price">Price</p>
                                <p class="cart-item__quantity">Quantity</p>
                                <p class="cart-item__stock">Stock</p>
                                <p class="cart-item__subtotal">Subtotal</p>
                            </div>    
                            
                    
                       
                        <?php 

                        $subtotalfinal = 0;

                        

                        // Check if there are items in the cart
                        if (!empty($_SESSION['cart'])) {
                            // Loop through each item in the cart
                            foreach ($_SESSION['cart'] as $cart_item) {
                               
                                     

                               
                                // Extract cart item details
                                $shoe_name = isset($cart_item['name']) ? $cart_item['name'] : '';
                                $shoe_price = isset($cart_item['price']) ? $cart_item['price'] : '';
                                $quantity = isset($cart_item['quantity']) ? $cart_item['quantity'] : '';
                                $stock = isset($cart_item['stock']) ? $cart_item['stock'] : '';
                                $subtotal = isset($cart_item['subtotal']) ? $cart_item['subtotal'] : '';
                                $shoe_img = isset($cart_item['image']) ? $cart_item['image'] : ''; // Check if 'image' key exists
                                $remove_id = isset($cart_item['id']) ? $cart_item['id'] : ''; // Check if 'image' key exists
                               
                                $subtotalfinal += $subtotal;

                                
                                // Display the cart item
                                echo " 
                                <div class='cart-item'>
                                <form method='post'>
                                <a href='cart.php?action=remove&id={$remove_id}'>
                                <i class='bx bx-x close-icon'></i>
                                </a>
                                <div class='cart-item__info'>
                                <img src='data:image/jpeg;base64," . base64_encode($shoe_img) . "' alt='' class='cart-item__image' />
                                <p class='cart-item__name-txt'>" . $shoe_name . "</p>
                                <p class='cart-item__price-txt'>GH₵" . $shoe_price . "</p>
                                        <input type='number' data-id=" . $remove_id . " name='number' value=" . $quantity ." inputmode='numeric' min='1' onchange='updateQuantity(this)' /> 
                                        <p class='cart-item__stock-txt'>" . $stock . "</p>
                                        <p class='cart-item__subtotal-txt'>GH₵<span class='subtotal-price'>" . $subtotal . "</span></p>
                                        </div>
                                        </form>
                               </div>
                               <div class='cart-line3'></div>";
                               
                               
                            }
                            
                            
                        }
                        else {
                                // If cart is empty, display a message
                                echo "Your cart is empty.";
                            }
                            
                            ?>
                               </div>
                            
                            
                            
                        </div>

                <div class='vertical-line'></div>
                    <div class='cart-right'>
                    <h2 class='cart-title'>Cart Totals</h2>
                    <div class='cart-line'></div>
                    <div class='cart-line2'>
                    <!-- Right cart content -->
                    <div class='cart-totals'>
                        <!-- Display cart totals -->
                        <p class='cart-subtotal'>Subtotal <span class='sub-price'>GH₵<?php echo $subtotalfinal; ?></span></p>
                        <p class='cart-total'>Total <span class='total-price'>GH₵<?php echo $subtotalfinal; ?></span></p>
                        <div class='cart-line2'>
                            <!-- Proceed to checkout button -->
                            <a href='checkout.php'>
                                <button type='submit' class='proceed-btn' onclick='payWithPaystack()'>Pay</button>
                            </a>
                        </div>
                    </div>
                </div>         
        </section>
        </main>

        

        <!--===== MAIN JS =====-->
        <script src="assets/js/main.js"></script>
        <script src="https://js.paystack.co/v1/inline.js"></script>

        <script>
            var userId = <?php echo json_encode($_SESSION['user_id']); ?>; // Assuming you have a user ID stored in the session
            var timestamp = <?php echo time(); ?>; // Current timestamp
            var uniqueRef = userId + '_' + timestamp;

    function payWithPaystack() {
        var handler = PaystackPop.setup({
            key: 'pk_live_8808ccbb75ff610e6fb8b4e7339c97c7057ffca6',
            email: '<?php echo $_SESSION['email']; ?>',
            amount: <?php echo $subtotalfinal * 100; ?>, 
            currency: 'GHS', // Replace with the currency code (GHS for Ghana Cedis)
            ref: uniqueRef,
            callback: function(response) {
                // Handle the callback, e.g., redirect to a success page or update order status
                console.log(response);
            },
            onClose: function() {
                alert('Payment was not completed');
            }
        });
        handler.openIframe();
    }
        
    
        </script>
    </body>
    </html>