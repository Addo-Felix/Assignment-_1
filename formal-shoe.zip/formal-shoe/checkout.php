<?php
session_start();

require_once 'paystack-php-master/src/autoload.php';
use Yabacon\Paystack;

// Initialize Paystack with your secret key
$paystack = new Paystack('sk_live_2635a24d0d980a135fa4ca2dac795cb645527bd7');

// Initialize subtotalfinal
$subtotalfinal = 0;

// Check if cart session variable is not set, initialize it as an empty array
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = array();
}

// Calculate total amount in the cart
if (!empty($_SESSION['cart'])) {
    // Loop through each item in the cart
    foreach ($_SESSION['cart'] as $cart_item) {
        // Add each item's subtotal to the total
        $subtotalfinal += $cart_item['subtotal'];
    }
}

try {
    // Customer's mobile number
    $customer_mobile_number = '+233XXXXXXXXX'; // Replace with the customer's mobile number

    // Initialize transaction with Paystack
    $transaction = $paystack->transaction->initialize([
        'amount' => (int)$subtotalfinal * 100, // Convert amount to kobo
        'email' => $_SESSION['email'], // Customer's email
        'metadata' => [
            'custom_fields' => [
                [
                    'display_name' => "Mobile Number",
                    'variable_name' => "mobile_number",
                    'value' => $customer_mobile_number // Customer's mobile number
                ]
            ]
        ]
    ]);


            // Connect to the database
            $servername = "localhost";
            $username = "nk";
            $password = "";
            $dbname = "formal-shoe";

            $conn = new mysqli($servername, $username, $password, $dbname);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            $total_price = $subtotalfinal; // Assuming $subtotalfinal is the total price of the order

            // Set the order status
            $order_status = 'success';
            
            // Get the current date and time
            $order_date = date('Y-m-d H:i:s');
            
            // Insert order details into the database
            $sql = "INSERT INTO orders (user_email, total_price, order_status, date) VALUES (?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sdss", $_SESSION['email'], $total_price, $order_status, $order_date);
            $stmt->execute();

            
            
            // Check if the order was successfully inserted
            if ($stmt->affected_rows > 0) {
                $order_id = $stmt->insert_id; // Get the ID of the inserted order
            
                $_SESSION['order_id'] = $order_id;

                         // Update stock for each item in the cart
        foreach ($_SESSION['cart'] as $cart_item) {
            $sneaker_id = $cart_item['id'];
            $quantity_purchased = $cart_item['quantity'];

            // Update the stock in the database
            $update_stock_sql = "UPDATE shoe_detail SET stock = stock - ? WHERE id = ?";
            $stmt = $conn->prepare($update_stock_sql);
            $stmt->bind_param("ii", $quantity_purchased, $sneaker_id);
            $stmt->execute();
        }

               
                // Redirect the user to Paystack Checkout
                header('Location: ' . $transaction->data->authorization_url);
                unset($_SESSION['cart']);
                exit();
            } else {
                // Handle the case where the order insertion failed
                // You can redirect the user to an error page or display an error message
                echo "Error: Order insertion failed.";
            }
    // Redirect to Paystack Checkout
    header('Location: ' . $transaction->data->authorization_url);
    exit();
        
} catch (\Yabacon\Paystack\Exception\ApiException $e) {
    die($e->getMessage());
}
?>
