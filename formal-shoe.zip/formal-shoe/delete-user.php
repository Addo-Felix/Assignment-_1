<?php
// Check if the shoe ID is set in the URL
if(isset($_GET['id'])) {
    $user_id = $_GET['id'];

    // Connect to the database
    $servername = "localhost";
    $username = "nk";
    $password = "";
    $dbname = "formal-shoe";
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare and execute SQL query to delete the shoe
    $sql = "DELETE FROM login WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    
    if ($stmt->execute()) {
        // If deletion is successful, redirect back to manage-products.php
        echo "<script>alert('User deleted'); window.location = 'accounts.php';</script>";
        exit();
    } else {
        // If there is an error in the deletion process, display an error message
        echo "Error deleting record: " . $conn->error;
    }

    // Close the database connection
    $conn->close();
} else {
    // If shoe ID is not set in the URL, redirect back to manage-products.php
    header("Location: accounts.php");
    exit();
}
?>
