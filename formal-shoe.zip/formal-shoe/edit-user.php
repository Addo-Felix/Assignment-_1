<?php
// Check if the user ID is provided in the URL parameter
if (isset($_GET['id'])) {
    // Retrieve the user ID from the URL
    $user_id = $_GET['id'];

    // Database connection
    $servername = "localhost";
    $username = "nk";
    $password = "";
    $dbname = "formal-shoe";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Retrieve user data based on the provided ID
    $sql = "SELECT * FROM login WHERE id= ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Fetch user data
        $user_data = $result->fetch_assoc();
    } else {
        echo "<script>alert('User not found); window.location = 'accounts.php';</script>";
    }

    $conn->close();
} else {
    echo "User ID not provided";
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if all required fields are set
    if(isset($_POST['fullname'], $_POST['email'])) {
        // Retrieve form data
        $name = $_POST['fullname'];
        $email = $_POST['email'];

        // Database connection
        $servername = "localhost";
        $username = "nk";
        $password = "";
        $dbname = "formal-shoe";

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Prepare SQL statement to update user details
        $sql = "UPDATE login SET fullname='$name', email='$email' WHERE id='$user_id'";
        $stmt = $conn->prepare($sql);

        if ($stmt->execute()) {
            echo "<script>alert('User updated successfully'); window.location = 'accounts.php';</script>";
            exit();
        } else {
            echo "Error updating record: " . $conn->error;
        }
    }
    $conn->close();
} 

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- ==== FONT AWESOME ==== -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- ==== BOOTSTRAP JS ==== -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>

    <!-- ==== BOOSTRAP CSS ==== -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">

    <!-- ===== CSS ===== -->
    <link rel="stylesheet" href="./assets/css/admin.css" />

    <!-- ===== BOX ICONS ===== -->
    <link
      href="https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css"
      rel="stylesheet"
    />

    <title>Edit User</title>
</head>
<body>
    <!--===== HEADER =====-->
    <header class="l-header" id="header">
      <nav class="nav">
          <a class="navbar-title" href="manage-products.php">
              <h3 class="nav-h3">Formal-Shoes Dashboard</h3>
          </a>
        <div class="nav__toggle" id="nav-toggle">
        </div>
        
    </div>
  </nav>
</header>

<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 col-lg-2 sidebar">
            <ul>
                <li><a href="manage-products.php"><i class="bx bxs-package"></i>Manage Products</a></li>
                <li><a href="orders.php"><i class="bx bxs-cart"></i>Orders</a></li>
                <li class="active"><a href="accounts.php"><i class="bx bxs-user"></i>User Accounts</a></li>
            </ul>
        </div>
        <!-- Main Content Area -->
        <div class="col-md-9 col-lg-10 main-content">
            <!-- Main content goes here -->
        </div>
    </div>
</div>

 
    <main class="l-main">

        <section class="featured section bd-grid">

    
    <!-- <h2>Edit shoe</h2> -->
    <form action="edit-user.php?id=<?php echo $user_id; ?>"  method="post" enctype="multipart/form-data">
        <input type="hidden" name="shoe_id" value="<?php echo $user_data['id']; ?>">
        <label for="name">Fullname:</label><br>
        <input type="text" id="name" name="fullname" value="<?php echo $user_data['fullname']; ?>"><br>
        <label for="brand">Email:</label><br>
        <input type="text" id="email" name="email" value="<?php echo $user_data['email']; ?>"><br>
        <input type="submit" value="Update">
    </form>
</main>
</section>
</body>
</html>
