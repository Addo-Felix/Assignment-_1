<?php
// Start session
session_start();

// Check if the user is not logged in
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    // Redirect to the login page
    header("Location: login.html");
    exit();
}
$servername = "localhost";
$username = "nk";
$password = "";
$dbname = "formal-shoe";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize search query
$search_query = "";

// Check if search query is set
if (isset($_GET['search'])) {
    $search_query = $_GET['search'];

    $pages = array(
      'Bata' => 'bata.php',
      'bata' => 'bata.php',
      'Lee Cooper' => 'lee-cooper.php',
      'lee cooper' => 'lee-cooper.php',
      'new' => 'new-shoes.php',
      'New' => 'new-shoes.php',
      'Red Chief' => 'red-chief.php',
      'red Chief' => 'red-chief.php',
      'Hush Puppies' => 'hush-puppies.php',
      'hush puppies' => 'hush-puppies.php'
  );
  if (array_key_exists(strtolower($search_query), $pages)) {
    // Redirect to the corresponding page
    header("Location: " . $pages[strtolower($search_query)]);
    exit();
}
}

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- ==== FONT AWESOME ==== -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- ==== BOOTSTRAP JS ==== -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>

    <!-- ==== BOOSTRAP CSS ==== -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">

    <!-- ===== CSS ===== -->
    <link rel="stylesheet" href="./assets/css/styles.css" />

    <!-- ===== BOX ICONS ===== -->
    <link
      href="https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css"
      rel="stylesheet"
    />

    <title>Formal-shoe</title>
  </head>
  <body>
    <!--===== HEADER =====-->
    <header class="l-header" id="header">
      <nav class="nav bd-grid">
        <div class="nav__toggle" id="nav-toggle">
          <i class="bx bxs-grid"></i>
        </div>

        <a href="index.html" class="nav__logo">Formal-Shoes</a>

        <div class="nav__menu" id="nav-menu">
          <ul class="nav__list">
            <li class="nav__item">
              <a href="index.php" class="nav__link">Home</a>
            </li>
          
            <li class="nav__item">
              <a href="shop.php" class="nav__link active">Products</a>
            </li>

            <li class="nav__item">
              <a href="cart.php" class="nav__link">Cart</a>
            </li>

            <?php


// Check if the user is logged in
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {

      echo "<li class='nav__item'>";
      echo "<div class='profile'>";
      echo   " <i class='bx bx-user user-icon' id='account-icon' onclick='toggleDropdown()'></i>";
      echo "</div>";
      echo "</li>";
        echo '<div class="dropdown-content" id="logout-dropdown"><h5 class="logout-text" onclick="logout()">Logout</h5></div>';
  }  
   
    if(isset($_SESSION['logout']) && $_SESSION['logout'] === true) {
      // Unset all session variables
      // $_SESSION = array();
    
      // Destroy the session
      // session_destroy();
    
      // Redirect back to the index page
      header("Location: login.html");
      exit();
    }
    
    ?>

          </ul>
        </div>
        
      </nav>
    </header>

    <main class="l-main">
      <section class="featured section bd-grid" id="shop">
      <div class="search-container">
    <form action="shop.php" method="GET" class="search-form">
        <input type="text" name="search" placeholder="Search for shoes...">
        <i class="bx bx-search search-icon"></i>
    </form>
</div>
        <!-- <h2 class="section-title">All Products</h2> -->
        <div class="dropdown" id="categoryDropdown">
          <button class="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
            Hush Puppies
          </button>
          <ul class="dropdown-menu">
          <li><a class="dropdown-item" href="shop.php" data-category="All">All</a></li>
          <li><a class="dropdown-item" href="new-shoes.php" data-category="New">New</a></li>
          <li><a class="dropdown-item" href="lee-cooper.php" data-category="Lee Cooper">Lee Cooper</a></li>
          <li><a class="dropdown-item" href="bata.php" data-category="Bata">Bata</a></li>
          <li><a class="dropdown-item" href="red-chief.php" data-category="Red Chief">Red Chief</a></li>
          <li><a class="dropdown-item" href="hush-puppies.php" data-category="Hush Puppies">Hush Puppies</a></li>
          </ul>
        </div>

        <div class="featured__container bd-grid">

        <?php

          $servername = "localhost";
          $username = "nk";
          $password = "";
          $dbname = "formal-shoe";

          // Create connection
          $conn = new mysqli($servername, $username, $password, $dbname);

          // Check connection
          if ($conn->connect_error) {
              die("Connection failed: " . $conn->connect_error);
          }
      // Initialize category variable
      $category = "";

      // Check if a category query parameter is present in the URL
      if (isset($_GET['category'])) {
          // Sanitize the category value to prevent SQL injection
          $category = $conn->real_escape_string($_GET['category']);
      }

      // Construct the SQL query based on the selected category
      $sql = "SELECT * FROM shoe_detail WHERE brand='Hush Puppies'";
      if (!empty($category)) {
          
      }

      // Execute the query
      $result = $conn->query($sql);

      // Check if there are any results
      if ($result->num_rows > 0) {
          // Output data of each row
          while ($row = $result->fetch_assoc()) {
                // Echo HTML code for each shoe
                echo "<article class='shoe'>
                        <img src='data:image/jpeg;base64," . base64_encode($row['image']) . "' alt='' class='shoe__img' />
                        <span class='shoe__name'>" . $row['name'] . "</span>
                        <span class='shoe__brand'><span class='brand-text'>Brand:</span>" . $row['brand'] . "</span>
                        <span class='shoe__gender'><span class='gender-text'>Gender:</span>" . $row['gender'] . "</span>
                        <span class='shoe__price'>GH₵" . $row['price'] . "</span>
                        <a href='cart.php?action=add&id=" . $row['id'] . "' class='button-light'>Add To Cart <i class='bx bx-right-arrow-alt button-icon'></i></a>
                      </article>";
            }
        } else {
            echo "0 results";
        }

        // Close database connection
        mysqli_close($conn);
        ?>
        </div>

        <div class="shoe__pages bd-grid">
          <div>
            <span class="shoe__page">1</span>
            <span class="shoe__page">2</span>
            <span class="shoe__page">3</span>
            <span class="shoe__page">4</span>
            <span class="shoe__page">&#8594</span>
          </div>
        </div>
      </section>
    </main>

    <!--===== FOOTER =====-->
    <footer class="footer section">
      <div class="footer__container bd-grid">
        <div class="footer__box">
          <h3 class="footer__title">Formal-Shoes</h3>
          <p class="footer__description">New Collection of shoes 2024</p>
        </div>

        <div class="footer__box">
          <h3 class="footer__title">Explore</h3>
          <ul>
            <li><a href="#home" class="footer__link">Home</a></li>
            <li><a href="#featured" class="footer__link">Featured</a></li>
            <li><a href="#women" class="footer__link">Women</a></li>
            <li><a href="#men" class="footer__link">New</a></li>
          </ul>
        </div>

        <div class="footer__box">
          <h3 class="footer__title">Support</h3>
          <ul>
            <li><a href="#" class="footer__link">Product Help</a></li>
            <li><a href="#" class="footer__link">Customer Care</a></li>
            <li><a href="#" class="footer__link">Authorized Service</a></li>
          </ul>
        </div>

        <div class="footer__box">
          <a href="#" class="footer__social"><i class="bx bxl-facebook"></i></a>
          <a href="#" class="footer__social"
            ><i class="bx bxl-instagram"></i
          ></a>
          <a href="#" class="footer__social"><i class="bx bxl-twitter"></i></a>
        </div>
      </div>

      <p class="footer__copy">&#169; 2022 Formal-Shoes. All right reserved</p>
    </footer>


    <!--===== MAIN JS =====-->
    <script src="assets/js/main.js"></script>
  </body>
</html>
