<?php
session_start();

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    // Redirect to the login page
    header("Location: login.html");
    exit();
}

// Check if cart session variable is not set, initialize it as an empty array
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- ==== FONT AWESOME ==== -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- ==== BOOTSTRAP JS ==== -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>

    <!-- ==== BOOSTRAP CSS ==== -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">


    <!-- ===== CSS ===== -->
    <link rel="stylesheet" href="./assets/css/styles.css" />

    <!-- ===== BOX ICONS ===== -->
    <link
      href="https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css"
      rel="stylesheet"
    />

    <title>Formal-shoe</title>
  </head>
  <body>
    <!--===== HEADER =====-->
    <header class="home-l-header" id="header">
      <nav class="nav bd-grid">
        <div class="nav__toggle" id="nav-toggle">
          <i class="bx bxs-grid"></i>
        </div>

        <a href="index.php" class="nav__logo">Formal-Shoes</a>

        <div class="nav__menu" id="nav-menu">
          <ul class="nav__list">
            <li class="nav__item">
              <a href="index.php" class="nav__link active">Home</a>
            </li>
          
            <li class="nav__item">
              <a href="shop.php" class="nav__link">Shop</a>
            </li>

            <li class="nav__item">
              <a href="cart.php" class="nav__link">Cart</a>
            </li>


            <?php


// Check if the user is logged in
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {

      echo "<li class='nav__item'>";
      echo "<div class='profile'>";
      echo   " <i class='bx bx-user user-icon' id='account-icon' onclick='toggleDropdown()'></i>";
      echo "</div>";
      echo "</li>";
        echo '<div class="dropdown-content" id="logout-dropdown"><h5 class="logout-text" onclick="logout()">Logout</h5></div>';
  } else { 
    
    echo   "<div class='login'>";
          echo "<li class='nav__item'>";
          echo  "<a href='login.html'>"; 
          echo   " <button type='submit' class='login-btn'>Login</button>";
          echo     " </li>";
          echo  "</a>";
        echo "</div>";
    } 
   
    if(isset($_SESSION['logout']) && $_SESSION['logout'] === true) {
      // Unset all session variables
    
      // Destroy the session
    
      // Redirect back to the index page
      header("Location: login.html");
      exit();
    }
    
    ?>
            
            

          </ul>
        </div>

      </nav>
    </header>



    <main class="l-main">
      <!--===== HOME =====-->
      <section class="home" id="home">
        <img src="assets/img/home.jpg" class="home-image">
        <div class="home__container bd-grid">
          <div class="home__shoe">
         
        
          <div class='home__data'>

            <span class='home__new'>EXPLORE AUTHENTIC FORMAL SHOES</span>
            <!-- <p class='home__description'>
                We provide the best authentic leather shoes
            </p> -->
            <a href='new-shoes.php' class='button'>Explore now</a>";
       
          </div>
        </div>
      </section>

      <!--===== FEATURED =====-->
      <section class="featured section" id="featured">
      <h2 class="section-title">FEATURED</h2>

      <div class="featured__container bd-grid">
      
      <?php
      // Your PHP code to fetch random data from the database goes here
      $servername = "localhost";
      $username = "nk";
      $password = "";
      $dbname = "formal-shoe";
  
      // Create connection
      $conn = new mysqli($servername, $username, $password, $dbname);
  
      // Check connection
      if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
      }
  
      // Select three random rows from your database
      $sql = "SELECT * FROM shoe_detail LIMIT 3";
      $result = mysqli_query($conn, $sql);

     if (mysqli_num_rows($result) > 0) {
        // Output data of each row
        while ($row = mysqli_fetch_assoc($result)) {
          
       echo "<article class='shoe'>
            <img src='data:image/jpeg;base64," . base64_encode($row['image']) . "' alt='' class='shoe__img' />
            <span class='shoe__name'>" . $row['name'] . "</span>
            <span class='shoe__price'>GH₵" . $row['price'] . "</span>
            <a href='cart.php?action=add&id=" . $row['id'] . "' class='button-light'>Add To Cart <i class='bx bx-right-arrow-alt button-icon'></i></a>
          </article>";
      
        }
      } else {
        echo "0 results";
      }
      $conn->close();
      ?>  
      </div>
      </section>

      <!--===== COLLECTION =====-->
      <!-- <section class="collection section">
        <div class="collection__container bd-grid">
          <div class="collection__card">
            <div class="collection__data">
              <h1 class="collection__name">NIKE</h1> -->
              <!-- <p class="collection_description"></p> -->
              <!-- <a href="Nike.php" class="button-light"
                >View <i class="bx bx-right-arrow-alt button-icon"></i
              ></a>
            </div>

            <img
              src="assets/img/collection1.png"
              alt=""
              class="collection__img"
            />
          </div>

          <div class="collection__card">
            <div class="collection__data">
              <h1 class="collection__name">Addidas</h1> -->
              <!-- <p class="collection_description"></p> -->
              <!-- <a href="Adidas.php" class="button-light"
                >View <i class="bx bx-right-arrow-alt button-icon"></i
              ></a>
            </div>

            <img
              src="assets/img/collection2.png"
              alt=""
              class="collection__img"
            />
          </div>
        </div>
      </section> -->

      

            <!--===== NEW COLLECTION =====-->
            <section class="new section" id="new">
        <h2 class="section-title">NEW COLLECTION</h2>

        <div class="new__container bd-grid">

          
       <div class='new__mens'>
              <img src='./assets/img/lee cooper leather lace up.png'  class='new__mens-img' />
              <h3 class='new__title'>New Collection</h3>
              <span class='new__price'>from GH₵500</span>
              <a href='new-shoes.php' class='button-light'>View Collection <i class='bx bx-right-arrow-alt button-icon'></i
              ></a>
            </div>
  
            <div class='new__shoe'>
              <div class='new__shoe-card'>
                <img
                  src='./assets/img/bata budapester.png'
                  class='new__shoe-img'
                />
                
              </div>
  
              <div class='new__shoe-card'>
                <img
                  src='./assets/img/red chief tan slip-on.png'
                  
                  class='new__shoe-img'
                />
                
              </div>
  
              <div class='new__shoe-card'>
                <img
                  src='./assets/img/Moccasin Slip-on bata.png'
                  class='new__shoe-img'
                />
               
              </div>
  
              <div class='new__shoe-card'>
                <img
                  src='./assets/img/wojas hush puppies.png'
                  class='new__shoe-img'
                />
                
              </div>
            </div>

          </div>
      </section>

      <!--===== NEWSLETTER =====-->
      <section class="newsletter section">
        <div class="newsletter__container bd-grid">
          <div>
            <h3 class="newsletter__title">
              Subscribe And Get <br />
              10% OFF
            </h3>

            <p class="newsletter__description">
              Get 10% discount on all products
            </p>
          </div>

          <form action="" class="newsletter__subscribe">
            <input
              type="text"
              placeholder="demo@email.com"
              class="newsletter__input"
            />
            <a href="#" class="button">Subscribe</a>
          </form>
        </div>
      </section>
    </main>

    <!--===== FOOTER =====-->
    <footer class="footer section">
      <div class="footer__container bd-grid">
        <div class="footer__box">
          <h3 class="footer__title">Formal-Shoes</h3>
          <p class="footer__description">New Collection of shoes 2024</p>
        </div>

        <div class="footer__box">
          <h3 class="footer__title">Explore</h3>
          <ul>
            <li><a href="#home" class="footer__link">Home</a></li>
            <li><a href="#featured" class="footer__link">Featured</a></li>
            <li><a href="#women" class="footer__link">Women</a></li>
            <li><a href="#men" class="footer__link">New</a></li>
          </ul>
        </div>

        <div class="footer__box">
          <h3 class="footer__title">Support</h3>
          <ul>
            <li><a href="#" class="footer__link">Product Help</a></li>
            <li><a href="#" class="footer__link">Customer Care</a></li>
            <li><a href="#" class="footer__link">Authorized Service</a></li>
          </ul>
        </div>

        <div class="footer__box">
          <a href="#" class="footer__social"><i class="bx bxl-facebook"></i></a>
          <a href="#" class="footer__social"
            ><i class="bx bxl-instagram"></i
          ></a>
          <a href="#" class="footer__social"><i class="bx bxl-twitter"></i></a>
        </div>
      </div>

      <p class="footer__copy">&#169; 2024 Formal-Shoes. All right reserved</p>
    </footer>

    <!--===== MAIN JS =====-->
    <script src="assets/js/main.js"></script>

    <script>
      const header = document.getElementById('header');
  const navLinks = document.querySelectorAll('.nav__link');
    const navLogo = document.querySelector('.nav__logo');
  const profileIcon = document.querySelector('.user-icon');

  // Function to change header background and text color on scroll
  function changeHeaderOnScroll() {
    // Calculate scroll position
    const scrollPosition = window.scrollY;

    
    if (scrollPosition > 0) {
      header.style.backgroundColor = 'white'; 
      navLinks.forEach(link => {
        link.style.color = 'black'; 
      });
      navLogo.style.color = 'black';
      profileIcon.style.color = 'black'; 
    
    
    } else {
      header.style.backgroundColor = 'transparent'; 
      navLinks.forEach(link => {
        link.style.color = 'white'; 
      });
      navLogo.style.color = 'white'; 
      profileIcon.style.color = 'white';
    }
  }

  // Event listener for scroll
  window.addEventListener('scroll', changeHeaderOnScroll);
    </script>

  </body>
</html>