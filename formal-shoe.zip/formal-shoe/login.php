<?php
//  Establish a connection to the database
$servername = "localhost";
$username = "nk";
$db_password = "";
$dbname = "formal-shoe";

$conn = new mysqli($servername, $username, $db_password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

//  Retrieve user input from the login form
$email = $_POST['email'];
$password = $_POST['password'];


// Query the database to retrieve hashed password for the provided email
$stmt = $conn->prepare("SELECT password FROM login WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 1) {
    // Verify if the provided password matches the hashed password from the database
    $row = $result->fetch_assoc();
    $hashedPasswordFromDB = $row['password'];

    if (password_verify($password, $hashedPasswordFromDB)) {
        // Passwords match, user is authenticated
        session_start();

        $_SESSION['loggedin'] = true;
        $_SESSION['email'] = $email;
        
        header("Location: index.php");
        exit();
       
    } else {
        // Password is incorrect, set error message
        echo "<script>alert('Invalid email or password'); window.location = 'login.html';</script>";
    }
} else {
    // Email not found in the database, set error message
    echo "<script>alert('Invalid email or password'); window.location = 'login.html';</script>";
    }

$stmt->close();
$conn->close();
?>
