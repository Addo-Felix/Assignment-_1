<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- ==== FONT AWESOME ==== -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- ==== BOOTSTRAP JS ==== -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>

    <!-- ==== BOOSTRAP CSS ==== -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">

    <!-- ===== CSS ===== -->
    <link rel="stylesheet" href="./assets/css/admin.css" />

    <!-- ===== BOX ICONS ===== -->
    <link
      href="https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css"
      rel="stylesheet"
    />

    <title>Formal-shoe</title>
  </head>
  <body>
    <!--===== HEADER =====-->
    <header class="l-header" id="header">
      <nav class="nav">
          <a class="navbar-title" href="manage-products.php">
              <h3 class="nav-h3">Formal-Shoes Dashboard</h3>
          </a>
        <div class="nav__toggle" id="nav-toggle">
        </div>
        
    </div>
  </nav>
</header>

<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 col-lg-2 sidebar">
            <ul>
                <li class="active"><a href="manage-products.php"><i class="bx bxs-package"></i>Manage Products</a></li>
                <li><a href="orders.php"><i class="bx bxs-cart"></i>Orders</a></li>
                <li><a href="accounts.php"><i class="bx bxs-user"></i>User Accounts</a></li>
            </ul>
        </div>
        <!-- Main Content Area -->
        <div class="col-md-9 col-lg-10 main-content">
            <!-- Main content goes here -->
        </div>
    </div>
</div>

 
    <main>

        <section class="featured section bd-grid">

        <div class="main-content">
        <?php 
    $servername = "localhost";
    $username = "nk";
    $password = "";
    $dbname = "formal-shoe";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    // Fetch total number of shoes in the database
    $sqlTotal = "SELECT COUNT(*) AS total FROM shoe_detail";
    $resultTotal = mysqli_query($conn, $sqlTotal);
    $rowTotal = mysqli_fetch_assoc($resultTotal);
    $totalshoes = $rowTotal['total'];

    // Fetch total number of RedChief shoes
    $sqlRedChief = "SELECT COUNT(*) AS totalRedChief FROM shoe_detail WHERE brand = 'Red Chief'";
    $resultRedChief = mysqli_query($conn, $sqlRedChief);
    $rowRedChief = mysqli_fetch_assoc($resultRedChief);
    $totalRedChiefshoes = $rowRedChief['totalRedChief'];

    // Fetch total number of Bata shoes
    $sqlBata = "SELECT COUNT(*) AS totalBata FROM shoe_detail WHERE brand = 'Bata'";
    $resultBata = mysqli_query($conn, $sqlBata);
    $rowBata = mysqli_fetch_assoc($resultBata);
    $totalBatashoes = $rowBata['totalBata'];
    
    // Fetch total number of HushPuppies shoes
    $sqlHushPuppies = "SELECT COUNT(*) AS totalHushPuppies FROM shoe_detail WHERE brand = 'Hush Puppies'";
    $resultHushPuppies = mysqli_query($conn, $sqlHushPuppies);
    $rowHushPuppies = mysqli_fetch_assoc($resultHushPuppies);
    $totalHushPuppiesshoes = $rowHushPuppies['totalHushPuppies'];
    
    // Fetch total number of LeeCooper shoes
    $sqlLeeCooper = "SELECT COUNT(*) AS totalLeeCooper FROM shoe_detail WHERE brand = 'Lee Cooper'";
    $resultLeeCooper = mysqli_query($conn, $sqlLeeCooper);
    $rowLeeCooper = mysqli_fetch_assoc($resultLeeCooper);
    $totalLeeCoopershoes = $rowLeeCooper['totalLeeCooper'];

    mysqli_close($conn);
?>
    <!-- Card section -->
    <div class="card-container">
        <!-- Total number of shoes card -->
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Total shoes</h5>
                <p class="card-text"><?php echo $totalshoes; ?></p>
            </div>
        </div>
        <!-- RedChief shoes card -->
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Red Chief shoes</h5>
                <p class="card-text"><?php echo $totalRedChiefshoes; ?></p>
            </div>
        </div>
     <!-- Bata shoes card -->
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Bata shoes</h5>
                <p class="card-text"><?php echo $totalBatashoes; ?></p>
            </div>
        </div>

        <!-- HushPuppies shoes card -->
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Hush Puppies shoes</h5>
                <p class="card-text"><?php echo $totalHushPuppiesshoes; ?></p>
            </div>
        </div>
    

        <!-- LeeCooper shoes card -->
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Lee Cooper shoes</h5>
                <p class="card-text"><?php echo $totalLeeCoopershoes; ?></p>
            </div>
        </div>
    </div>

    <!-- Manage products section -->
    <section class="manage-products">
      <a href="add_shoe.php">
      <button  class="add-btn">Add shoe</button>
      </a>
        <h2 class="section-title">Manage Products</h2>
        <!-- Table to display shoe details -->
        <table class="shoe-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Brand</th>
                    <th>Price</th>
                    <th>Stock</th>
                    <th>Image</th>
                    <th>Action</th>
                </tr>
            </thead>
           
            <tbody>

            <?php 
            $servername = "localhost";
            $username = "nk";
            $password = "";
            $dbname = "formal-shoe";
  
            // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);
  
            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }
            
          // Fetch shoe data from the database
          $sql = "SELECT * FROM shoe_detail";
          $result = mysqli_query($conn, $sql);

          if (mysqli_num_rows($result) > 0) {
            // Output data of each row
            while ($row = mysqli_fetch_assoc($result)) {
        
           echo "<tr>
            <td>" . $row['id']. "</td>
            <td>" .$row['name'] . "</td>
            <td>" . $row['brand'] . "</td>
            <td>GH₵" . $row['price'] . "</td>
            <td>". $row['stock'] . "</td>
            <td><img src='data:image/jpeg;base64," . base64_encode($row['image']) . "'style='max-width: 100px;'></td>
            <td>
                <a href='edit.php?id=" . $row['id'] ."'>
                <button class='edit-btn'>Edit</button>
                </a>

                <a href='delete.php?id=" . $row['id'] ."'>
                <button class='delete-btn'>Delete</button>
                </a>
            </td>
        </tr>
          </tbody>";
            }
          } else {
             echo "no information found";
          }
          mysqli_close($conn);
          ?>
        
      </section>
    </main>


    <!--===== MAIN JS =====-->
    <script src="assets/js/main.js"></script>
  </body>
</html>
