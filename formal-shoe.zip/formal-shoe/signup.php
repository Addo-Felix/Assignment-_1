<?php

// Initialize errors array

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $fullname = $_POST['fullname'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirmPassword = $_POST['Cpassword'];

        // If there are no errors, proceed with database insertion
        $servername = "localhost";
        $username = "nk";
        $db_password = ""; 
        $dbname = "formal-shoe"; 

        // Create connection
        $conn = new mysqli($servername, $username, $db_password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Prepare SQL statement to insert user data into the database
        $sql = "INSERT INTO login (fullname, email, password) VALUES (?, ?, ?)";

        // Prepare and bind parameters
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sss", $fullname, $email, $hashedPassword);

        // Execute the SQL statement
        if ($stmt->execute()) {
            echo "<script>alert('User registered successfully'); window.location = 'login.html';</script>";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }

        // Close statement and database connection
        $stmt->close();
        $conn->close();
    }
