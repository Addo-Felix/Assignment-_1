<?php
session_start();

if (isset($_POST['id']) && isset($_POST['quantity'])) {
    $id = $_POST['id'];
    $quantity = $_POST['quantity'];

    // Loop through cart items to find the item to update
    foreach ($_SESSION['cart'] as $key => &$cart_item) {
        if ($cart_item['id'] === $id) {
            // Update the quantity of the item
            $cart_item['quantity'] = $quantity;
            $cart_item['subtotal'] = $cart_item['price'] * $quantity;
            break;
        }
    }

    // Update the total subtotal and total in the session
    $totalSubtotal = array_sum(array_column($_SESSION['cart'], 'subtotal'));
    $_SESSION['total_subtotal'] = $totalSubtotal;
    $_SESSION['total'] = $totalSubtotal; // Assuming total and total_subtotal are the same in this context
}
?>
